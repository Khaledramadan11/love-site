export const loveConfig = {
  name: "بسبوستي",
  startDate: "2026-08-26T00:00:00",
  message: "ستبقى الحب الذي لا يُهزم، سأحبك وكأنني لم أجد أعظم من قلبك لأحتفظ به.",
  subtitle: "حكاية صغيرة، وذكرى تستحق أن تبقى.",
  photos: [
    "/photos/photo_1.jpg",
    "/photos/photo_2.jpg",
    "/photos/photo_3.jpg",
    "/photos/photo_4.jpg"
  ]
};
