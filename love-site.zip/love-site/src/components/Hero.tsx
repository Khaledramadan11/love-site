"use client";
import { loveConfig } from "../config/loveConfig";
import styles from "./Hero.module.css";

export default function Hero(){
  return <section className={styles.hero}>
    <div className={styles.glow}/><div className={styles.petal}>✦</div><div className={styles.petal2}>✦</div>
    <div className={styles.content}>
      <div className={styles.heart}>♥</div>
      <p className={styles.kicker}>إلى {loveConfig.name}</p>
      <h1>أجمل الحكايات تبدأ<br/><span>بتفصيلة صغيرة</span></h1>
      <p className={styles.subtitle}>{loveConfig.subtitle}</p>
      <a href="#counter" className={styles.button}>ابدأ الحكاية ↓</a>
    </div>
  </section>
}
