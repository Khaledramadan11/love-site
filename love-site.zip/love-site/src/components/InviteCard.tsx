"use client";
import { useState } from "react";
import styles from "./InviteCard.module.css";
export default function InviteCard({name,message}:{name:string,message:string}){const [open,setOpen]=useState(false);return <section className={styles.section}><div className={styles.card}><div className={styles.seal}>♥</div><p className={styles.to}>رسالة خاصة إلى</p><h2>{name}</h2>{open?<div className={styles.message}><p>{message}</p><button onClick={()=>setOpen(false)}>إغلاق</button></div>:<button className={styles.open} onClick={()=>setOpen(true)}>افتح الرسالة 💌</button>}</div></section>}
