import Hero from "../components/Hero";
import TimeCounter from "../components/TimeCounter";
import ParallaxTimeline from "../components/ParallaxTimeline";
import TulipCatcher from "../components/TulipCatcher";
import InviteCard from "../components/InviteCard";
import { loveConfig } from "../config/loveConfig";

export default function Home() {
  return (
    <main>
      <Hero />
      <TimeCounter startDate={loveConfig.startDate} />
      <ParallaxTimeline photos={loveConfig.photos} />
      <TulipCatcher />
      <InviteCard name={loveConfig.name} message={loveConfig.message} />
    </main>
  );
}
