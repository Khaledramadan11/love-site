# بسبوستي ❤️

موقع Next.js تفاعلي بسيط لصفحة ذكرى خاصة.

## التشغيل

```bash
npm install
npm run dev
```

ثم افتح `http://localhost:3000`.

## الصور
ضع الصور في `public/photos/` بالأسماء:
- photo_1.jpg
- photo_2.jpg
- photo_3.jpg
- photo_4.jpg

يمكن تعديل الاسم والتاريخ والرسالة من `src/config/loveConfig.ts`.
